import xlrd
import psutil
import csv

def readfromXL():
	f = xlrd.open_workbook('/home/mohideen/Desktop/sample.xlsx')
	sh = f.sheet_by_name('sample')
	for i in sh.get_rows():
		print(i)
	for i in range(sh.nrows):
		print(sh.row_values(i))


def processCount():
	proc = [i.name() for i in psutil.process_iter()]
	return {i: proc.count(i) for i in set(proc)}

def csvWriter():
	f = open('processCount.csv', 'w')
	writer = csv.writer(f)
	writer.writerow(('Process Name', 'Count'))
	out = processCount()
	for i in out.items():
		writer.writerow(i)
	f.close()
	return "Successfull!"

print(csvWriter())
